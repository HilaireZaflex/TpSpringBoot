/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.OdkApprenant.demo.services;

import com.OdkApprenant.demo.model.Apprenant;
import java.util.List;

/**
 *
 * @author hilaire.daliwa
 */
public interface ApprenantServices {
    
    Apprenant ajouterApprenant(Apprenant a);
    Apprenant modifierApprenant(Apprenant a);
    void supprimerApprenantById(Integer id_apprenant);
    Apprenant afficherApprenant(Integer id_apprenant);
    List<Apprenant> afficherToutApprenant();
    
}
